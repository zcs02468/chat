import React, { Component } from "react";
import { Menu } from "antd";
import IconFont from "../component/IconFont/index";
import "./SliderNav.css";
import {Link}  from 'react-router-dom'


class SliderNav extends Component {
    handleClick = (e) => {
        console.log("click ", e);
    };
    state = {
        navList: [
            {
                name: "首页",
                icon: "icon-mode",
                key: "/"
            },
            {
                name: "邮件订阅管理",
                icon: "icon-email",
                key: "/email"
            },
            {
                name: "博客管理",
                icon: "icon-email",
                key: "/blogList"
            },
            {
                name: "博客编辑",
                icon: "icon-email",
                key: "/editor"
            },
        ]
    };

    render() {
        return (
                <div className="nav-box">
                    <Menu onClick={this.handleClick} style={{ width: 256 }} mode="inline" defaultSelectedKeys="navOne0" className="nav">
                        {this.state.navList.map((item, index) => {
                            return (
                                <Menu.Item key={`navOne${index}`}>
                                    <Link to={item.key}>
                                        <IconFont type={item.icon} />
                                        <span>{item.name}</span>
                                    </Link>
                                </Menu.Item>
                            );
                        })}
                    </Menu>
                </div>
        );
    }
}

export default SliderNav;
