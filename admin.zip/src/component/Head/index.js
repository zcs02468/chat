import React,{Component} from "react"
import "./style.css"


class Head extends Component {
    render() {
        return (
            <div className="head-box">
                <header className="App-header">1111</header>
            </div>
        )
    }
}


export default Head;