import { createFromIconfontCN } from "@ant-design/icons";

const IconFont = createFromIconfontCN({
    scriptUrl: "//at.alicdn.com/t/font_1752029_1nxjlg760dr.js",
});

export default IconFont