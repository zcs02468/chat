import React, { Component } from "react";
import { Card, List } from 'antd';
import mockData from "./mock"
import "./style.scss";


class BlogPage extends Component {
    constructor() {
        super()
        this.list = mockData()
        console.log( this.list,'this.list' );
        
    }
    render() {
        return (
            <div className="blog-page">
                <div className="blog-head">头部区域</div>
                <div className="blog-content">
                    <List
                        rowKey="id"
                        split={false}
                        className="list-box"
                        dataSource={this.list}
                        renderItem={(item) => (
                            <List.Item>
                                <Card className="card-box" style={{ width: 928 }}>
                                    <div className="imgBox">
                                        <img alt={item.title} src={item.cover} />
                                    </div>
                                    <div className="card-content">
                                        <h2>{item.title}</h2>
                                    </div>
                                    <div>
                                    </div>
                                </Card>
                            </List.Item>
                        )}
                    />
                </div>
            </div>
        );
    }
}

export default BlogPage;
