import React,{Component} from "react"
import "./index.css"


class Home extends Component {
    render() {
        return (
            <div className="page-box">首页</div>
        )
    }
}

export default Home;